# Kat Planı Tasarım Aracı — Devir Notu

Yeni sohbete başlarken bu dosyayı ve `kat-plani-tasarim.html` dosyasını ekleyin.

## SIRADAKİ İŞ (güncel: 2026-06-10, oturum v4)
1. **Vaka diff'leri**: `vakalar/vaka-1..5.svg` motor çıktısıdır (durum gömülü).
   Kullanıcı bunları uygulamada içe aktarıp elle düzeltir ve düzeltilmiş hâli
   `vakalar/vaka-N-...-elden.svg` adıyla aynı klasöre koyar. Yeni oturumda:
   ikisini de oda bazında ayrıştır (alan+bbox+konum; bu oturumda kat-plani-20/21
   için yapıldığı gibi, bkz. md.15), farklardan kural çıkar, motoru ayarla,
   `tests/` ile regresyon doğrula. Diff çıkarırken daire alanları aynıysa ayırıcılara
   dokunulmamış demektir → tüm fark daire İÇİ karardır (en değerli sinyal).
2. **Mevzuata otomatik uydurma** (bilinen sınır #5): "Mevzuata Uydur" düğmesi —
   slimUnitAntre deseni genellenir, runChecks ihlal listesi altyapısı hazır.
3. Eski-SVG çözümleyiciye balkon/parsel aktarımı (md.16'daki bilinen eksik).

## Ne bu?
Tek dosyalık web uygulaması (`kat-plani-tasarim.html`). Türkiye mevzuatına göre şematik
apartman/villa kat planı üretir. Kullanıcı bina sınırını çizer (kenar açısı 15°'nin
katlarına, uzunluk 0,5 m ızgaraya oturur), isteğe bağlı parsel sınırı çizer (bahçe
alanı + TAKS + çekme mesafesi denetimi) ve dış duvarlara balkon ekler (vektörel
katman; hücre motoruna girmez, daire tablosunda açık alan olarak listelenir),
daire tiplerini girer (oda/salon/ebeveyn banyosu/açık mutfak/adet), "Yerleşimi
Oluştur" der; motor koridor + çekirdek + daireleri yerleştirir, mevzuat panelinde denetler.

## Mimari (script içi akış)
1. **Izgara**: 0,5 m hücreler (`M=0.5`), poligon içi test, `cm` Int16Array bölge haritası.
2. **Koridor**: maliyet aramalı ana bant (sığ işe yaramaz şerit bırakan konum cezalı) +
   11 m'den derin kanatlara dik kollar (cepheye kadar uzar, uçta daire saramaz; 10 m'den
   yakın çift kol ayıklanır).
3. **Çekirdek**: merdiven 5×3, asansör(ler) kat kuralına göre (3 kat→yer, 4+→1, 11+→2;
   asansör/teknik blokları tam çekirdek derinliğinde — cep oluşmaz), yangın merdiveni
   bina yüksekliği >21,5 m veya 4+ katta EN UZAK uca (minimax kaçış).
4. **Bölgeler**: atanmamış bitişik bileşenler; hole baktıkları yöne göre N/S/E/W daire
   şeritlerine bölünür (`splitZone`, sürüklenebilir ayırıcılar `customCutsZ`).
5. **Daire içi (`layoutUnit`)**: T-plan — giriş sırası (mutfak/banyo/WC, derinliği
   MUTFAĞIN ideal oranına göre 2–3 m), 1 m iç hol kolu (her odaya erişecek kadar uzun,
   fazlası köşe odalara bağışlanır), cephe sırası (salon + yataklar). Ebeveyn banyosu
   yatak odasının hol köşesinden oyulur. Şerit yalnız gerektiği kadar geniş; artık uçlar
   salona (küçükse banyo/mutfağa) gider. Kiler: yalnız ≥110 m² dairede, ≤5 m².
   ÇEKİRDEK GÖLGESİ: hol bandı derinliğinde hücresi olmayan sütunlar (merdiven/asansör
   arkası raf) tespit edilir; ≥2 m gölge varsa salon o uca yaslanır — yoksa oransal
   bölücü yatak odasını çekirdek arkasına atar, oda antreye değemez ve meltNoAccess
   yutar (ayırıcı çekirdek üstünden geçirilince yaşanan "yatak odası kayboldu" hatası).
6. **Onarım hattı** (sırayla): `fixOrphans` (kopuk parça → komşuya) → `repairUnits`
   (mevzuata takılan oda komşudan 0,5 m şeritlerle büyür; antre yenirse bütünlük denetimi
   + geri alma) → `purgeSlivers` (kılçık oda eritilir; TEK salon ölmez, emici oda salona
   dönüşür) → `meltNoAccess` (antreye değmeyen oda eritilir) → `carveMissing` (banyosuz
   daireye antre komşusu odadan banyo oyulur) → `fixOrphans`.
7. **Denetim (`runChecks`)**: PAİY piyes ölçüleri (salon 12/3,0; yatak 9/2,5; mutfak
   3,3/1,5; banyo 3/1,5; WC 1,2/1,0; salon+mutfak 15,3), asansör/yangın/kaçış (30 m),
   sığınak >8 daire notu, oda programı raporu ("3 yataktan 2 yerleşti"), biçimsiz oda
   (<%55 doluluk), ince-uzun mutfak (>1:2,8). Sorunlar üstte, tıklayınca odağa gider.
8. **UI**: yüzen daire tablosu (sürüklenebilir), rozetler kapı üstünde, SVG/PNG dışa
   aktarma. Duvar uzunlukları: yakınlaşınca hepsi; aynı duvarı iki oda da etiketliyorsa
   tek etiket duvar üstüne haleyle (`paint-order:stroke`) yazılır; imleç odanın
   üzerindeyken o odanın ölçüleri HER ölçekte belirgin, diğerleri %15 soluk
   (`hoverRoomId`, svg mouseleave'de temizlenir).
9. **Oda duvarı düzenleyici** (`computeWallRuns`/`moveWallStep`/`dragWallTo`): aynı
   dairenin iki odası arasındaki düz duvar parçaları (kare tutamaç) sürüklenir; duvar
   0,5 m hücre şeritleri aktararak yürür. Korumalar: şeridin tamamı donöre ait olmalı
   (3. odaya taşmaz), donör ≥1 m² kalır, donör kopuyorsa adım geri alınır. Her adımda
   `runChecks` + daire tablosu canlı yenilenir; `runChecks`e oda→antre (EB. BANYO→eb.
   yatak) komşuluk denetimi eklendi. Elle duvar değişiklikleri `generate()` (yeniden
   üretim veya ayırıcı sürükleme) ile sıfırlanır — bilinçli karar.
10. **Geri Al katmanlı**: `editHistory` yığını duvar/ayırıcı/oda düzenlemelerini tutar
   (`finishDrag` ve oda işlemleri yazar, `undoEdit` geri alır); Geri Al önce bunları
   adım adım tüketir, yığın boşalınca eski davranışa (planı boz / köşe sil) düşer.
   `generate()` duvar VE oda girdilerini (bölge kimlikleri yeniden doğar),
   `resetCuts()` ayırıcı girdilerini siler.
11. **Oda ekle/sil** (`addRoom`/`removeRoom`, sağ tık menüsü `#roomMenu`): üretim
   sonrası TEK dairede düzenleme. Silme: oda, aynı dairede en uzun ortak duvarlı
   komşusuna katılır (purgeSlivers mantığı); antre, merdiven ve TEK salon silinemez.
   Ekleme: ev sahibi odadan, antreye komşu tohumdan tip boyutlu pencere oyulur
   (carveMissing mantığı; sığmazsa küçülür, donör ≥3 m² ve bağlantılı kalır, yoksa
   iptal); ince ayar mevcut duvar sürüklemeyle. Her ikisi de daire `spec`inin
   KOPYASINI günceller (oda±, salon±, mutfak sil→acik:true, EB. BANYO sil→
   ensuite:false) — runChecks program raporu yanlış alarm vermez, kardeş daireler
   etkilenmez. `editHistory`ye `{type:'room', op:'add'|'remove', ...}` yazılır.
   EB. BANYO da menüde: yalnız yatak odasından oyulur (köşeden, antre koşulu aranmaz),
   ev sahibi oda 'EB. YATAK ODASI'ya çevrilir + spec.ensuite=true (geri alınabilir).
   EB. BANYO satırı artık HER odada görünür: yatak dışında pasif ("yatak odasına sağ
   tıklayın"), dairede zaten varsa pasif ("zaten var"; addRoom'da da çift koruması var —
   denetim/kapı eşleşmesi ada bağlı olduğundan daire başına tek EB. BANYO).
   YENİ ODA TIK NOKTASINA OYULUR: addRoom(host,def,hint) — hint sağ tıklanan hücre;
   tohum, adaylar (antre komşusu / eb'de tüm hücreler) içinden hint'e en yakını.
   Pencere artık tohumu içeren TÜM konumlardan en çok hücre kapsayanı seçer (hint'li
   yolda) — köşe tohumda sliver/false dönme hatası giderildi. Kullanıcı odayı sağa
   dayamak istiyorsa odanın sağ tarafına sağ tıklar. Hintsiz çağrı (testler) eski
   davranışta. Test: tests/oda-hint.js (13). NOT: tohum antre komşuluğuyla sınırlı
   kaldığından (kapı şartı) hint ancak antre arayüzü boyunca kaydırır; arayüz 1-2
   hücreyse yer değişmez — ince ayar yine duvar sürükleme.
12. **Tek daire/kat** (`trySingleUnit`): apartman modunda kat başına 1 daire varsa bant
   koridor İSRAFTIR (karşı kanat sahipsiz kalıp ORTAK DEPO'ya düşüyordu — 600 m² tabanda
   261 m² depo!). Bunun yerine kompakt çekirdek (merdiven+asansör+teknik+yangın TEK
   SIRADA, 3 m derinlik) cepheye yaslanır, önüne 1,5 m lobi; kalan TÜM alan tek daireye.
   Yerleşim üst cepheden taranır (lobi daireye bakmalı — `facing`), olmazsa alt cephe;
   hiç sığmazsa eski bant düzenine geri düşer. Ayırıcı tutamacı yok; ince ayar duvar
   sürükleme + oda ekle/sil. İlgili düzeltme: `layoutUnit`te giriş şeridi artık
   `kset` (koridora GERÇEKTEN komşu sütunlar) üstüne oturur — antre↔lobi kapısı
   garanti; çok daireli düzende kset≈bset olduğundan davranış değişmez (harness aynı).

13. **Antre inceltme** (`slimAntres`/`slimUnitAntre`, üretim sonunda otomatik + antre
   sağ tık menüsünde "Antreyi kırp"): antre kolları odaların içine taşıyor, kör uç
   bırakıyordu (32×16'da 19-22,5 m² antre). Fazla hücre şeritleri `moveWallStep`
   adımlarıyla odalara geri verilir (önce mevzuat açığı olana, sonra salona).
   Korumalar: antre bağlantılı + ≥3,5 m², hiçbir yer <1 m inceltilmez (`thinCells`:
   her hücre 2×2 tam-antre blokta), oda→antre komşulukları korunur ve ASIL KAPI:
   `runChecks` ihlal sayısı artamaz (kapı yeri/cephe/biçim/program... hepsi bununla
   güvende; runChecks artık `out` dizisini DÖNDÜRÜR). Sonuç: 32×16'da antreler
   19→5,5 / 22,5→10 m². L-daire girişi yapısal olarak ~%13,7'de kalabilir (banyo
   yönü 0,5 m boğaz oluşturduğu için haklı reddedilir) — test eşiği %14.
14. **Oda etiketi/takas/bölme/antre uzatma** (sağ tık menüsü, `RETYPE` listesi):
   *Tipini değiştir* (`retypeRoom`): ad+tip değişir, spec KOPYASI güncellenir
   (yatak↔oda sayısı, mutfak↔acik); tek salon ve EB. BANYO'lu EB. YATAK korunur
   (`retypeGuard`). *Takas* (`swapRooms`): aynı dairede iki odanın ad/tipi yer
   değiştirir, hücreler yerinde, spec değişmez. *Odayı böl* (`splitRoom`): bbox
   ortasından dikine/enine; yeni parça NÖTR `ODA` tipiyle doğar (COLORS/TYPE_TR'ye
   'oda' eklendi; denetimlerde piyes ölçüsü aranmaz), ince ayar duvar sürükleme,
   adlandırma Tipini değiştir — "duvar birleşince kayboldu" sorununun geri yolu.
   *Antreyi bu odaya uzat* (`extendAntreTo`, yalnız antreye komşu OLMAYAN odada
   görünür): daire hücrelerinde Dijkstra (ıslak hacim pahalı), yol 1 m'ye
   genişletilir; donör odalar bağlantılı+≥1 m² kalmazsa geri alınır. Antresiz
   daireye menüden "+ ANTRE" (addRoom, u.antre atanır). Antre SİLİNEMEZ (giriş).
   Geri Al: `retype`/`swap` yeni geçmiş tipleri; böl/+ANTRE `room/add` yolunu kullanır
   (undo'da `u.antre` temizlenir); uzat/kırp `wallsnap`.

15. **Motor v21 ayarı** (kullanıcının kat-plani-20→21 elle ince ayarından çıkarılan
   kurallar; girdi: 40×12, 5 kat, 2+1 eb ×4):
   *Ders #1 — ensuite sözü tutulur*: eski köşe-sabit EB. BANYO oyması L-odalarda 0-10
   hücrelik kırpık üretip purgeSlivers'a yeniliyordu → 4 daireden 3'ü SESSİZCE
   ensuite'siz kalıyordu. Yeni `carveCornerBath`: odada EN ÇOK hücre kapsayan cw×cw
   pencere (skor: hücre×1000 − kalan-bbox − antre-cephesi×60; oda dikdörtgene yaklaşır,
   kapı cephesi yenmez). `ensureEnsuite` onarım hattında (carveMissing sonrası) VE slim
   sonrası ikinci tur: önce yatağa komşu KİLER dönüştürülür, olmadı en büyük yataktan
   oyulur; başka ≥9 m² yatak varsa eb. yatak 6 m²'ye inebilir. purgeSlivers banyo eşiği
   2,8 m²/1,2 m (2×1,5 eb. banyo meşru). runChecks'e "Eb. banyo" satırı eklendi
   (yoksa bad). Kiler: ensuite istenen dairede eşik 110→130 m² (program > lüks).
   *Ders #2 — komb plan (sığ bant)*: cepheye <2,5 m kalacaksa giriş sırası İPTAL;
   antre koridor boyu 1,5 m OMURGA, ıslak hacimler dâhil tüm odalar omurgaya asılır
   (orta odalar ≈derinlik−1,5, uç odalar tam derinlik). Omurga önce TAM genişlik atanır,
   cephe odaları yerleşince uç sütunlar uç odalara geri verilir (kestirimli uç payı
   orta odayı omurga dışına taşırıp kapısız bırakıyordu — salon erimesi). Çekirdek
   gölgesi varsa EB. YATAK o uca (eb. banyo kapısız yaşayabilen tek oda olarak gölgeye
   oyulur — kullanıcının yangın merdiveni arkası hamlesi), salon karşı uçta. `unit.comb`
   işaretli dairede slimAntres tabanı max(6 m², %12) — omurga 3,5 m²'ye kemirilince
   odalar köşe temasıyla şişiyordu. 10×2,5 salon / 7×2 mutfak şeritleri böyle öldü;
   40×12 sığ bant artık v21 ile örtüşüyor (YATAK 3×3,5 birebir). Derin bantta (≥2,5 m
   cephe payı) T-plan korunur — kullanıcı da v21'de korudu. *Ders #3*: giriş sırasına
   yatak itilirse şerit derinliği min 2,5 m (2 m yatak yasadışıydı).
16. **İçe/dışa aktarma** (`stateSnapshot`/`restoreState`/`importPlanText`): dışa
   aktarılan SVG `<metadata id="kpState">` içinde TAM durumu taşır (girdiler + bölge
   hücreleri + kapılar + komb işaretleri) → "SVG içe aktar" düğmesi / pencereye
   sürükle-bırak, generate() ÇAĞIRMADAN birebir geri kurar — elle düzenlemeler böylece
   KALICILAŞIR (bilinen sınır #1'in çözüm yolu). Durumsuz eski SVG'ler `importLegacySvg`
   ile geometriden çözülür: 0,5 m hücre kareleri (renk→tip) + duvar çizgileri (bölge
   ayrımı) + #faf8f3 kapı boşlukları (daire gruplama: kapı grafiği bileşenleri, ortak
   alanlar hariç) + etiketler (BANYO/WC renk ayrımı, adlar; ölçü yazıları paint-order
   ile elenir). Kapısız oda grubu en uzun ortak duvarlı komşu daireye katılır; spec'ler
   odalardan çıkarılır, özdeşler adetle birleşir. kat-plani-20/21.svg gerçek dosyalarla
   doğrulandı (21: 4 daire, oda alanları birebir, 0 ihlal). Sınırlar: eski SVG'den
   balkon/parsel/ayırıcı taşınmaz; kat sayısı SVG'de yok → mevcut UI değeri kalır.
17. **Vaka döngüsü** (`vakalar/vaka-1..5.svg`, durum gömülü): orta blok, geniş-sığ
   (komb), L-şekil, derin blok (demiryolu), villa 5+1. Akış: kullanıcı içe aktarır →
   elle ince ayar → SVG indir → yeni sohbette ikisi diff'lenir → motor kuralı çıkarılır
   (bu oturumda 20→21 ile yapılanın aynısı). 3-5'te bilinçli ihlal var (ince ayar
   malzemesi: 3'te yatak penceresiz + eksik yatak, 4'te eksik yatak, 5'te villa programı).

## Bilerek verilen kararlar
- Salon "emici"dir: program alanı doldurmuyorsa artık alan salona gider (her alternatif
  daha kötüydü: şişen banyolar, dev kiler, sahte odalar).
- Yangın merdiveni uçta DOĞRU: çekirdek ortadayken en kötü nokta uçtur (minimax).
- Aşırı/yetersiz program çizilmez, dürüstçe raporlanır (kullanıcı ayırıcı sürükler ya da
  daire sayısını değiştirir).
- Mutfak dar kenarı ≥2 m (≤45 m² dairede yasal 1,5 m'ye düşebilir).

## Bilinen sınırlar / sonraki adımlar
1. ~~Oda duvarı sürükleme~~ TAMAMLANDI (md.9), Geri Al destekli (md.10).
   ~~Elle değişiklikler yeniden üretimde kaybolur~~ ÇÖZÜLDÜ (md.16): SVG indir →
   içe aktar döngüsü tam durumu saklar; generate() yine sıfırlar (bilinçli).
   Eksik kalan: duvar yalnız kendi doğrultusunda kayar (L-duvar köşesi taşınamaz).
2. Balkon ve ışıklık üretimi yok (ışıklık bilinçli kaldırıldı; iç banyo/WC havalandırması
   şaft notuyla geçiliyor).
3. Çok egzotik taban şekilleri (artı/haç, çentikli) hâlâ "biçimsiz" bayrakları üretebilir.
4. Tek tip kat: zemin/normal kat ayrımı, otopark, sığınak çizimi yok.
5. **Mevzuata otomatik uydurma** (sıradaki büyük iş): kullanıcı elle yapıyor, motor da
   yapabilir. Önerilen yol: slimUnitAntre desenini genelle — "Mevzuata Uydur" düğmesi,
   `runChecks` ihlali kalan odalar için `moveWallStep` adımlarını dener, ihlal sayısı
   azalan adımları kabul eder (kapı/erişim/biçim korumaları slim'dekiyle aynı; altyapı
   hazır: runChecks artık ihlal listesi döndürüyor).
6. `extendAntreTo` koridoru 2. hücreyi rastgele yandan alır — pürüzlü kenar bırakabilir;
   ince ayar duvar sürüklemeye kalıyor.
7. ~~Antre odalara taşıyor / şişiyor~~ TAMAMLANDI (md.13).
8. ~~Oda etiketi değiştirme/takas, oda bölme, antre menü işlemleri~~ TAMAMLANDI (md.14).
9. Bayat test düzeltmeleri: `wall-drag.js` artık uygulamadaki gibi `snap:` koyar, boş
   (yutulmuş) donörü meşru sayar, dış sınır duvarlarını tanır. DİKKAT: çalışma ağacı
   HEAD'den ilerideydi (commit'lenmemiş oturum işi) — taban karşılaştırması için
   `git show HEAD:` DEĞİL, değişiklik öncesi çalışma kopyası kullanılmalı.

## Test altyapısı
Kendi kendine yeten (doğrudan `node tests/<dosya>.js`) testler: `room-edit.js` (55),
`antre-slim.js` (51: antre kompakt ≤ max(6 m², %14), ince çıkıntı yok, erişim, bütünlük),
`etiket.js` (31: retype/swap/split/extendAntreTo + geri al + korumalar),
`oda-hint.js` (13: hint'li/hintsiz addRoom, yön denetimi, EB. BANYO çift koruması),
`import.js` (15: snapshot→restore gidiş-dönüş bölge imzası birebir + eski-SVG geometri
çözümleyici; 2. bölüm `linkedom` ister, yoksa kendini atlar — `npm i linkedom`).
DİKKAT (2026-06-10/2): bu makinede `/tmp/app.js` ve `/tmp/plan*.svg` başka kullanıcıya
ait kilitli dosyalar — eski testleri koşarken yolları sed ile değiştirilen KOPYALAR
kullanıldı (`sed s|/tmp/app.js|$HOME/app.js|`); testlerin kendisi değiştirilmedi.
DİKKAT (2026-06-10): runChecks'te mutfak oran denetimi kaldırılırken açık kalan
`if(...){` bloğu TÜM script'i SyntaxError'la kırıyordu (uygulama hiç açılmıyordu) —
düzeltildi. Şüpheli bozulmada ilk bakılacak yer: script'i çekip `node --check`.
Diğerleri `/tmp/app.js` ister (hazırlık komutu tests/README.md'de).
`tests/room-edit.js` artık depoda ve kendi kendine yeter (`node tests/room-edit.js`):
oda sil/ekle/geri al, bütünlük (hücre toplamı + cm tutarlılığı), spec kopyası,
korumalar, villa senaryosu, EB. BANYO, tek daire/kat düzeni (5 ve 12 kat) — 55 denetim. Diğerleri sohbet içinde kurulmuştu:
Node ile başsız test: HTML'den `<script>` çekilir, DOM stub'lanır, `generate()` çağrılır;
senaryolar: 32×16 standart, 21×18 4×3+1, L-şekil, 48×27 derin blok, villa, stüdyolar.
Denetimler: hücre bütünlüğü, her odanın antreye komşuluğu, banyosuz/salonsuz daire,
mutfak boyutları. Yeni sohbette aynı yöntem hızla yeniden kurulabilir.
